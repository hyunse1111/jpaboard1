package org.pgm.runningpro.controller.admin;

import lombok.RequiredArgsConstructor;
import org.pgm.runningpro.entity.User;
import org.pgm.runningpro.service.UserService;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin/users")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class AdminUserController {

    private final UserService userService;

    @GetMapping
    public String listUsers(
            @RequestParam(required = false) String search,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "false") boolean includeAdmin,
            Model model) {

        String safeSearch = (search == null) ? "" : search.trim();
        Page<User> userPage = userService.searchUsers(safeSearch, page, size, includeAdmin);

        model.addAttribute("users", userPage);
        model.addAttribute("search", safeSearch);
        model.addAttribute("includeAdmin", includeAdmin);
        model.addAttribute("pageTitle", "회원 관리");
        model.addAttribute("active", "users");
        model.addAttribute("viewName", "admin/users");

        return "admin/layout";
    }
    @PostMapping("/{id}/disable")
    public String disableUser(@PathVariable Long id, RedirectAttributes ra) {
        userService.disableUser(id);
        ra.addFlashAttribute("message", "회원이 비활성화되었습니다.");
        return "redirect:/admin/users";
    }

    @PostMapping("/{id}/enable")
    public String enableUser(@PathVariable Long id, RedirectAttributes ra) {
        userService.enableUser(id);
        ra.addFlashAttribute("message", "회원이 활성화되었습니다.");
        return "redirect:/admin/users";
    }

    @PostMapping("/{id}/delete")
    public String forceDeleteUser(@PathVariable Long id, RedirectAttributes ra) {
        try {
            userService.forceDeleteUser(id);
            ra.addFlashAttribute("message", "회원이 성공적으로 탈퇴되었습니다.");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/users";
    }
}