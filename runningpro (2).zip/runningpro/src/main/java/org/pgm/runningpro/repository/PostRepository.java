// src/main/java/org/pgm/runningpro/repository/PostRepository.java
package org.pgm.runningpro.repository;

import org.pgm.runningpro.entity.Post;
import org.pgm.runningpro.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface PostRepository extends JpaRepository<Post, Long> {

    List<Post> findByAuthor(User author);

    @Query("SELECT p FROM Post p WHERE p.deleted = false " +
            "AND (:search IS NULL OR " +
            "LOWER(p.title) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
            "LOWER(p.content) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
            "(p.author IS NOT NULL AND LOWER(p.author.nickname) LIKE LOWER(CONCAT('%', :search, '%'))))")
    Page<Post> searchPosts(@Param("search") String search, Pageable pageable);

    @Query("SELECT COUNT(p) FROM Post p WHERE p.deleted = false AND p.createdAt >= :today")
    long countByCreatedAtAfter(@Param("today") LocalDateTime today);

    @Query("SELECT p FROM Post p WHERE p.deleted = true")
    Page<Post> findDeletedPosts(Pageable pageable);
}