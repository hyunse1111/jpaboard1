package org.pgm.runningpro.config;

import lombok.RequiredArgsConstructor;
import org.pgm.runningpro.entity.Post;
import org.pgm.runningpro.entity.User;
import org.pgm.runningpro.repository.PostRepository;
import org.pgm.runningpro.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PostRepository postRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        String email = "hyunse@admin.com";
        String rawPassword = "12345";

        User admin = userRepository.findByEmail(email).orElseGet(() -> {
            User newAdmin = User.builder()
                    .email(email)
                    .password(passwordEncoder.encode(rawPassword))
                    .nickname("관리자")
                    .role("ADMIN")
                    .provider("LOCAL")
                    .enabled(true)
                    .build();
            userRepository.save(newAdmin);
            System.out.println("관리자 계정 생성: " + email + " / " + rawPassword);
            return newAdmin;
        });

        // 기존 계정 비밀번호 재설정
        if (admin.getPassword() == null || !passwordEncoder.matches(rawPassword, admin.getPassword())) {
            admin.setPassword(passwordEncoder.encode(rawPassword));
            admin.setEnabled(true);
            admin.setRole("ADMIN");
            userRepository.save(admin);
            System.out.println("비밀번호 강제 재설정: " + email);
        }
    }
    private void createTestUsers() {
        createTestUser("test@naver.com", "테스트유저", "1234");
        createTestUser("user1@gmail.com", "유저1", "1111");
    }

    private void createTestUser(String email, String nickname, String rawPassword) {
        if (userRepository.findByEmail(email).isEmpty()) {
            User user = User.builder()
                    .email(email)
                    .password(passwordEncoder.encode(rawPassword))
                    .nickname(nickname)
                    .role("USER")
                    .provider("LOCAL")
                    .enabled(true)
                    .deleted(false)
                    .build();
            userRepository.save(user);
            System.out.println("테스트 유저 생성: " + email);
        }
    }

}