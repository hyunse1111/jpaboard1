// src/main/java/org/pgm/runningpro/service/PostService.java
package org.pgm.runningpro.service;

import lombok.RequiredArgsConstructor;
import org.pgm.runningpro.entity.Post;
import org.pgm.runningpro.entity.User;
import org.pgm.runningpro.repository.PostRepository;
import org.pgm.runningpro.repository.UserRepository;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class PostService {

    private final PostRepository postRepository;
    private final UserRepository userRepository;

    public Page<Post> searchPosts(String search, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("id").descending());
        return postRepository.searchPosts(search, pageable);
    }

    @Transactional
    public void createPost(String title, String content, String username, boolean notice) {
        User author = userRepository.findByEmail(username)
                .orElseThrow(() -> new IllegalArgumentException("사용자를 찾을 수 없습니다."));

        if (author.isDeleted()) {
            throw new IllegalStateException("탈퇴한 사용자는 게시글을 작성할 수 없습니다.");
        }

        Post post = Post.builder()
                .title(title)
                .content(content)
                .author(author)
                .notice(notice)
                .build();
        postRepository.save(post);
    }

    @Transactional
    public void deletePost(Long id) {
        Post post = postRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("게시글을 찾을 수 없습니다."));
        post.setDeleted(true);
        postRepository.save(post);
    }

    @Transactional
    public void hardDeletePost(Long id) {
        Post post = postRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("게시글을 찾을 수 없습니다."));
        postRepository.delete(post);  // 물리 삭제
    }

    @Transactional
    public void restorePost(Long id) {
        Post post = postRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("게시글을 찾을 수 없습니다."));
        post.setDeleted(false);
        postRepository.save(post);
    }



    public Page<Post> getDeletedPosts(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("id").descending());
        return postRepository.findDeletedPosts(pageable);
    }
}