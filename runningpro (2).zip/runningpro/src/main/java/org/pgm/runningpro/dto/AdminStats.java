package org.pgm.runningpro.dto;

import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AdminStats {

    private long todayCount;
    private double todayGrowth;
    private long totalUsers;
    private long disabledCount;
}