// src/main/java/org/pgm/runningpro/service/UserService.java
package org.pgm.runningpro.service;

import lombok.RequiredArgsConstructor;
import org.pgm.runningpro.dto.AdminStats;
import org.pgm.runningpro.entity.User;
import org.pgm.runningpro.repository.PostRepository;
import org.pgm.runningpro.repository.UserRepository;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class UserService {

    private final UserRepository userRepository;
    private final PostRepository postRepository;

    // === 회원 검색 (삭제된 회원 제외 + 관리자 필터링) ===
    // searchUsers 메서드 수정
    // === 회원 검색 (삭제된 회원 제외 + 관리자 필터링) ===
    public Page<User> searchUsers(String search, int page, int size, boolean includeAdmin) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "id"));

        // search null 방지
        String safeSearch = (search == null) ? "" : search.trim();

        Page<User> result;

        if (includeAdmin) {
            // 관리자 포함 → 전체 검색
            result = userRepository.searchActiveUsers(safeSearch, pageable);
        } else {
            // 관리자 제외 → 쿼리에서 제외
            result = userRepository.searchNonAdminActiveUsers(safeSearch, pageable);
        }


        return result;
    }
    // === 관리자 통계 ===
    public AdminStats getStats() {
        LocalDateTime today = LocalDateTime.now().withHour(0).withMinute(0).withSecond(0).withNano(0);
        LocalDateTime yesterday = today.minusDays(1);
        LocalDateTime epoch = LocalDateTime.of(1970, 1, 1, 0, 0);

        long todayCount = userRepository.countActiveUsersCreatedAfter(today);
        long yesterdayCount = userRepository.countActiveUsersCreatedAfter(yesterday);
        long totalUsers = userRepository.countActiveUsersCreatedAfter(epoch); // deleted=false
        long disabledCount = userRepository.countDisabledUsers(); // deleted=false

        double growth = yesterdayCount == 0 ? 0.0
                : Math.round(((double) (todayCount - yesterdayCount) / yesterdayCount) * 1000.0) / 10.0;

        return AdminStats.builder()
                .todayCount(todayCount)
                .todayGrowth(growth)
                .totalUsers(totalUsers)
                .disabledCount(disabledCount)
                .build();
    }

    // === 강제 탈퇴 (논리 삭제) ===
    @Transactional
    public void forceDeleteUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("사용자를 찾을 수 없습니다: " + userId));

        if ("ADMIN".equals(user.getRole())) {
            throw new IllegalStateException("관리자는 탈퇴시킬 수 없습니다.");
        }

        if (user.isDeleted()) {
            return;
        }

        // 게시글 작성자 null 처리
        postRepository.findByAuthor(user).forEach(post -> {
            post.setAuthor(null);
            postRepository.save(post);
        });

        // 논리 삭제
        user.setDeleted(true);
        user.setEnabled(false);
        user.setEmail(user.getEmail() + "_deleted_" + System.currentTimeMillis());
        userRepository.save(user);
    }

    // === 비활성화 ===
    @Transactional
    public void disableUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("사용자를 찾을 수 없습니다: " + id));

        if ("ADMIN".equals(user.getRole())) {
            throw new IllegalStateException("관리자는 비활성화할 수 없습니다.");
        }

        if (!user.isEnabled()) {
            return;
        }

        user.setEnabled(false);
        userRepository.save(user);
    }

    // === 활성화 ===
    @Transactional
    public void enableUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("사용자를 찾을 수 없습니다: " + id));

        if ("ADMIN".equals(user.getRole())) {
            throw new IllegalStateException("관리자는 활성화 상태를 변경할 수 없습니다.");
        }

        if (user.isEnabled()) {
            return;
        }

        user.setEnabled(true);
        userRepository.save(user);
    }

    // === 배치 비활성화 ===
    @Transactional
    public void disableUsers(List<Long> userIds) {
        if (userIds == null || userIds.isEmpty()) return;
        userIds.forEach(this::disableUser);
    }

    // === 배치 탈퇴 ===
    @Transactional
    public void forceDeleteUsers(List<Long> userIds) {
        if (userIds == null || userIds.isEmpty()) return;
        userIds.forEach(this::forceDeleteUser);
    }
}