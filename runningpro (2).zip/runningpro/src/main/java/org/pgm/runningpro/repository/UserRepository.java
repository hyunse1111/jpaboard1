// src/main/java/org/pgm/runningpro/repository/UserRepository.java
package org.pgm.runningpro.repository;

import org.pgm.runningpro.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    // 활성 사용자 검색 (삭제 제외)
    @Query("SELECT u FROM User u WHERE u.deleted = false " +
            "AND (:search IS NULL OR " +
            "LOWER(u.email) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
            "LOWER(u.nickname) LIKE LOWER(CONCAT('%', :search, '%')))")
    Page<User> searchActiveUsers(@Param("search") String search, Pageable pageable);

    // 비관리자 활성 사용자 검색
    @Query("SELECT u FROM User u WHERE u.deleted = false AND u.role != 'ADMIN' " +
            "AND (:search IS NULL OR " +
            "LOWER(u.email) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
            "LOWER(u.nickname) LIKE LOWER(CONCAT('%', :search, '%')))")
    Page<User> searchNonAdminActiveUsers(@Param("search") String search, Pageable pageable);

    // 오늘 이후 가입자 수 (활성)
    @Query("SELECT COUNT(u) FROM User u WHERE u.deleted = false AND u.createdAt >= :date")
    long countActiveUsersCreatedAfter(@Param("date") LocalDateTime date);

    // 비활성 회원 수 (삭제 제외)
    @Query("SELECT COUNT(u) FROM User u WHERE u.deleted = false AND u.enabled = false")
    long countDisabledUsers();

    // 비관리자 활성 회원 수
    @Query("SELECT COUNT(u) FROM User u WHERE u.deleted = false AND u.role != 'ADMIN' " +
            "AND (:search IS NULL OR LOWER(u.email) LIKE LOWER(CONCAT('%', :search, '%')) OR LOWER(u.nickname) LIKE LOWER(CONCAT('%', :search, '%')))")
    long countNonAdminActiveUsers(@Param("search") String search);

    Page<User> findByEmailContainingOrNicknameContaining(String email, String nickname, Pageable pageable);

    Page<User> findByRoleNotAndEmailContainingOrNicknameContaining(
            String role, String email, String nickname, Pageable pageable);
}