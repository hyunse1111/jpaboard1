// src/main/java/org/pgm/runningpro/controller/admin/AdminPostController.java
package org.pgm.runningpro.controller.admin;

import lombok.RequiredArgsConstructor;
import org.pgm.runningpro.entity.Post;
import org.pgm.runningpro.service.PostService;
import org.pgm.runningpro.service.UserService;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin/posts")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class AdminPostController {

    private final PostService postService;
    private final UserService userService;

    // 게시글 목록
    @GetMapping
    public String listPosts(@RequestParam(required = false) String search,
                            @RequestParam(defaultValue = "0") int page,
                            @RequestParam(defaultValue = "10") int size,
                            Model model) {

        Page<Post> postPage = postService.searchPosts(search, page, size);

        model.addAttribute("posts", postPage);
        model.addAttribute("stats", userService.getStats());
        model.addAttribute("active", "posts");
        model.addAttribute("pageTitle", "게시글 관리");
        model.addAttribute("search", search);
        model.addAttribute("viewName", "admin/posts"); // 프래그먼트 이름

        model.addAttribute("postService", postService);
        return "admin/layout";
    }

    // 일반 게시글 작성 폼
    @GetMapping("/new")
    public String newPostForm(Model model) {
        model.addAttribute("stats", userService.getStats());
        model.addAttribute("active", "posts");
        model.addAttribute("pageTitle", "게시글 작성");
        model.addAttribute("viewName", "admin/post-form");
        model.addAttribute("isNotice", false);
        return "admin/layout";
    }

    // 일반 게시글 작성
    @PostMapping("/new")
    public String createPost(@RequestParam String title,
                             @RequestParam String content,
                             @AuthenticationPrincipal UserDetails userDetails,
                             RedirectAttributes ra) {
        try {
            postService.createPost(title, content, userDetails.getUsername(), false);
            ra.addFlashAttribute("message", "게시글이 작성되었습니다.");
        } catch (Exception e) {
            ra.addFlashAttribute("error", "작성 실패: " + e.getMessage());
        }
        return "redirect:/admin/posts";
    }

    // 공지 작성 폼
    @GetMapping("/notice/new")
    public String newNoticeForm(Model model) {
        model.addAttribute("stats", userService.getStats());
        model.addAttribute("active", "posts");
        model.addAttribute("pageTitle", "공지 작성");
        model.addAttribute("viewName", "admin/post-form");
        model.addAttribute("isNotice", true);
        return "admin/layout";
    }

    // 공지 작성
    @PostMapping("/notice")
    public String createNotice(@RequestParam String title,
                               @RequestParam String content,
                               @AuthenticationPrincipal UserDetails userDetails,
                               RedirectAttributes ra) {
        try {
            postService.createPost(title, content, userDetails.getUsername(), true);
            ra.addFlashAttribute("message", "공지가 작성되었습니다.");
        } catch (Exception e) {
            ra.addFlashAttribute("error", "작성 실패: " + e.getMessage());
        }
        return "redirect:/admin/posts"; // 폼 다시 렌더링 안 함
    }

    // 논리 삭제 (기본 삭제)
    @PostMapping("/{id}/delete")
    public String deletePost(@PathVariable Long id, RedirectAttributes ra) {
        try {
            postService.deletePost(id);
            ra.addFlashAttribute("message", "게시글이 삭제되었습니다. (복구 가능)");
        } catch (Exception e) {
            ra.addFlashAttribute("error", "삭제 실패: " + e.getMessage());
        }
        return "redirect:/admin/posts";
    }

    // 물리 삭제 (완전 삭제)
    @PostMapping("/{id}/hard-delete")
    public String hardDeletePost(@PathVariable Long id, RedirectAttributes ra) {
        try {
            postService.hardDeletePost(id);
            ra.addFlashAttribute("message", "게시글이 영구 삭제되었습니다. (복구 불가)");
        } catch (Exception e) {
            ra.addFlashAttribute("error", "영구 삭제 실패: " + e.getMessage());
        }
        return "redirect:/admin/posts";
    }

    // 복구 기능
    @PostMapping("/{id}/restore")
    public String restorePost(@PathVariable Long id, RedirectAttributes ra) {
        try {
            postService.restorePost(id);
            ra.addFlashAttribute("message", "게시글이 복구되었습니다.");
        } catch (Exception e) {
            ra.addFlashAttribute("error", "복구 실패: " + e.getMessage());
        }
        return "redirect:/admin/posts";
    }

    // 휴지통 페이지
    @GetMapping("/deleted")
    public String deletedPosts(@RequestParam(defaultValue = "0") int page,
                               @RequestParam(defaultValue = "10") int size,
                               @RequestParam(required = false) String search,
                               Model model) {

        Page<Post> deletedPosts = postService.getDeletedPosts(page, size);

        model.addAttribute("posts", deletedPosts);
        model.addAttribute("pageTitle", "휴지통");
        model.addAttribute("active", "posts");
        model.addAttribute("viewName", "admin/posts-deleted");
        model.addAttribute("search", search);
        model.addAttribute("isTrash", true);
        return "admin/layout";
    }
}